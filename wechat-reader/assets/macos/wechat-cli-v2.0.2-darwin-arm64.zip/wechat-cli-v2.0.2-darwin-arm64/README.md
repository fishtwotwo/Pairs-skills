# wechat-cli

面向人和 AI agent 的本机微信数据 CLI。

它读取 macOS / Windows 上 WeChat 4.x 的本地数据库，将聊天、联系人、群聊、媒体、朋友圈、收藏、转账与红包整理为稳定 JSON。消息正文默认实时读取，不上传、不发送消息，也不控制微信界面。

> 这是本地数据工具，不是微信机器人、公众号工具、Mini Program bridge 或 WeCom bot。

## 支持范围

- macOS arm64 + WeChat 4.x
- Windows amd64 + Windows WeChat / Weixin 4.x
- 文本、图片、视频、文件、链接、引用、合并转发、位置、语音
- 会话、联系人、联系人标签、群成员、全文搜索、朋友圈、收藏、转账、红包
- 紧凑 JSON、稳定分页、上下文展开、只读增量观察

微信需要保持登录，并至少打开过一个聊天。

## 安装

### macOS

稳定版发布在独立的 Release 仓库 `r266-tech/wechat-cli-releases`。它采用 ad-hoc 签名，未经 Apple 公证；安装器会校验 checksum、manifest 和组件哈希。

```bash
curl -fsSL https://github.com/r266-tech/wechat-cli-releases/releases/latest/download/install-release.sh | zsh
~/.local/share/wechat-cli/wxkey bootstrap
wechat-cli agent --pretty
```

首次执行 `wxkey bootstrap` 可能会退出并重新打开微信，并通过本机隐藏窗口请求管理员密码。为支持后续无人值守刷新，当前实现会将经 sudo 验证的密码存入当前用户 Keychain；密码不要粘贴给 agent、网页或终端日志。不接受这一取舍时请取消引导。安装完成后，建议在 **系统设置 → 隐私与安全性 → 完全磁盘访问权限** 中加入：

- `~/.local/share/wechat-cli/wechat-cli`
- `~/.local/share/wechat-cli/wxkey`

### Windows

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -Command "irm https://github.com/r266-tech/wechat-cli-releases/releases/latest/download/install-release.ps1 | iex"
wechat-cli cache refresh --force
wechat-cli agent --pretty
```

Windows 首次刷新时请保持微信登录，并打开一个普通聊天。

默认只安装 CLI，不注册外部 agent 协议，也不安装后台 watcher。安装位置：

- macOS：`~/.local/share/wechat-cli`
- Windows：`%LOCALAPPDATA%\wechat-cli`

## Agent 快速开始

先检查环境，不要先手动刷新缓存：

```bash
wechat-cli agent --pretty
wechat-cli status --pretty
wechat-cli tools
```

正常阅读从 `sessions → resolve-chat → timeline` 开始：

`sessions` 与 `unread` 直接读取实时 session 数据库；旧 metadata cache 不再决定最近会话和未读数量。`status.live_read_ok` 会实际打开数据库查询，配置存在本身不算读取成功。

```bash
wechat-cli sessions --type-filter private,group --limit 20
wechat-cli resolve-chat "聊天名"
wechat-cli timeline "聊天名" --limit 50
```

联系人与标签支持双向查询：

```bash
# 某联系人属于哪些标签：结果 contacts[].labels 返回 [{id,name}]
wechat-cli contacts --keyword "联系人昵称或备注" --limit 10

# 标签清单及每个标签的联系人数量
wechat-cli labels

# 某标签有哪些联系人；也可改用 --label-id <稳定 ID>
wechat-cli contacts --label "标签名" --limit 50
```

`timeline` 默认查询最新消息，再按时间正序展示。继续翻旧消息时，把 `data.query.cursor.next_before_message_token` 原样传回；向后续读使用 `next_after_message_token` / `--after-message-token`。消息的 `id.message_token` 同样可用于 `context` 或 `tail`，即使没有 server ID、不同分片的 local ID 重复也能定位：

```bash
wechat-cli timeline "聊天名" --before-message-token "$MESSAGE_TOKEN" --limit 50
```

搜索后展开上下文：

```bash
wechat-cli search "关键词" --in "聊天名" --limit 10
wechat-cli context "聊天名" --message-token "$MESSAGE_TOKEN" --before-count 10 --after-count 10
wechat-cli search-context "关键词" --in "聊天名" --context-limit 3
```

增量观察不会发消息，也不会控制微信 UI：

```bash
wechat-cli tail "聊天名" --cursor "$MESSAGE_TOKEN" --jsonl
wechat-cli watch --mode sessions --jsonl --follow
```

会话模式比较两次轮询的状态快照，可以观察纯未读数变化、同秒内保留下来的状态变化，以及会话新增和移除。它只表示轮询之间的净变化，不是完整事件日志：例如未读数在两次轮询之间从 1 变为 2 又回到 1，不会产生差异事件。首次调用返回最近窗口并为全部扫描到的会话建立基线（`query.initial_snapshot=true`）；扫描不完整时不推进游标，也不推断会话已移除。遇到 `session_scan_truncated` 可提高 `--scan-limit`（默认 5000，最大 100000）后用原游标重试；快照还受序列化大小上限约束，超限明确报错。

会话事件保持 `type=session`，`change=added|updated|removed` 表示相对上一基线的差异；`session_id` 用于对应同一会话。`removed` 表示它离开当前筛选下的可见集合，不等同于微信数据被删除。首次窗口是当前快照，不代表刚新增的会话。

`--cursor-storage auto` 是默认值：普通模式保存本机私有状态快照，返回短游标；严格只读模式自动使用不写游标状态文件的 `inline`。也可显式选择 `local` 或 `inline`，严格只读不接受 `local`。游标绑定账号与 `type_filter`、`keyword`、`unread_only` 筛选条件，续读时保持一致；可调整 `limit` 和 `scan_limit`，不支持非零 `offset`。旧时间戳游标可升级，但升级前发生的未读变化无法补回。inline 游标可能较长，可从 JSON 文件经 stdin 传入，避免命令行长度限制：

```bash
wechat-cli call-json tail < next-poll.json
```

`next-poll.json` 使用 `{"mode":"sessions","cursor":"<上次返回的完整 cursor>","cursor_storage":"inline"}`，并保留原筛选条件。`msg:v1` 消息 token 也应原样保存，不自行解析或拼接；它绑定账号、会话和原始消息位置。原锚点删除、迁移或排序/身份字段改变（包括未同步消息补齐 server ID）会返回 `message_cursor_stale`，此时重新读取 timeline 获取锚点；不能把 token 当作永久消息 ID。分片未完整可读时返回 `message_cursor_source_incomplete`，恢复可读后重试，不绕过游标继续推进。旧 `server_id_str` / `local_id` 参数继续支持；同传 token 与旧 ID 时必须一致。

本机游标依赖私有快照文件；目前不会自动过期，历史变更快照会累计占用磁盘，文件缺失或损坏会明确报错，此时需要重新建立基线。快照只保存会话标识元数据和状态指纹，不保存聊天正文；没有变化时复用原快照。inline 游标使用批次检查点（`freshness.cursor_scope=batch`），应在处理完整批次后保存顶层 `cursor`；单个事件不会重复携带完整 inline 游标。本机模式可以保存每事件的短游标。重试旧游标可能重放事件，消费端应允许重试。

每次调用都应检查：

- `ok`：调用是否成功
- `data.query.has_more` 与 cursor：是否需要继续分页
- `data.freshness`：数据来源与完整性
- `data.warnings` / `error`：缓存滞后、局部缺 key、媒体补齐失败等诊断

## 输出契约

stdout 默认是一行紧凑 JSON。人工查看加 `--pretty`。

成功：

```json
{"ok":true,"tool":"chat_timeline","command":"timeline","data":{"query":{},"freshness":{},"messages":[]}}
```

失败：

```json
{"ok":false,"error":{"code":"tool_error","message":"...","next_action":"..."}}
```

列表字段即使为空也保持为数组，适合 agent 稳定解析。只有 `tail/watch --jsonl` 与 `--follow` 输出 JSONL 事件流，不套标准 envelope。每批事件后追加一条 `type=checkpoint`，包含 `cursor/query/freshness/warnings`，空批次也有；消费端按 `type` 区分消息、会话和检查点，处理完批次后保存检查点游标。

通用调用接口：

```bash
wechat-cli tool-schema timeline
wechat-cli tools --profile all
wechat-cli call timeline --chat "聊天名" --limit 20
jq -n --arg chat "聊天名" '{chat:$chat,limit:20}' | wechat-cli call-json timeline
```

默认 schema 只显示高信噪比 canonical 参数；兼容 alias、维护与 debug 参数在 `--profile all` 中。

## 常用命令

| 命令 | 用途 |
| --- | --- |
| `agent` / `status` | 能力矩阵、本机 readiness、恢复动作 |
| `tools` / `tool-schema` | agent 工具面与参数 schema |
| `sessions` / `unread` | 最近会话与未读状态 |
| `resolve-chat` | 将昵称、备注或群名解析为稳定 talker |
| `contacts` / `labels` | 联系人及标签双向查询、标签成员数量 |
| `timeline` | 阅读聊天的默认入口 |
| `context` | 以消息 ID 展开前后文 |
| `search` / `search-context` | 本地全文搜索与上下文展开 |
| `tail` / `watch` | 只读增量消息、会话事件 |
| `media` | 图片、视频、文件的可读本机路径 |
| `members` | 群成员与群名片 |
| `favorites` | 微信收藏 |
| `sns-feed` / `sns-search` | 朋友圈时间线与搜索 |
| `transfers` / `red-packets` | 转账与红包记录 |
| `export` | 显式导出单个聊天到 JSONL / Markdown / HTML |
| `schema` / `sql` | 只读数据库诊断 |
| `cache status` | 元数据缓存诊断 |
| `update` | 更新到最新 GitHub release |
| `doctor` | 诊断 PATH、shim、版本、组件和实时读取状态 |
| `digest-source` | 显式生成私有聊天分析素材包 |
| `archive create` / `archive validate` | 显式创建或校验 plaintext SQLite 归档 |

`digest-source` 默认写入 `~/.wechat-cli/digests`，`archive create` 才会生成完整
plaintext SQLite 归档。两者都在 `--strict-read-only` 下拒绝执行；归档会写入
manifest、来源时间、key epoch 和每个数据库的 SHA-256，不改变实时读取默认路径。

典型消息行：

```json
{
  "id": {"local_id": 123, "server_id_str": "9876543210", "talker": "xxx@chatroom"},
  "time_iso": "2026-05-26T13:00:00+08:00",
  "sender": "Room Nickname",
  "sender_wxid": "wxid_alice",
  "sender_group_nickname": "Room Nickname",
  "sender_contact_display": "Alice",
  "is_from_me": false,
  "kind": "image",
  "text": "[图片]",
  "images": [{"path": "/Users/me/.wechat-cli/media-cache/xxx.jpg"}]
}
```

群消息优先使用可可靠解析的群内昵称作为 `sender`。`sender_wxid` 保留稳定身份，
`sender_contact_display` 与 `sender_group_nickname` 仅在对应信息可可靠解析时返回。

默认只返回人能在微信里看到、且 agent 可直接使用的信息。raw XML、CDN key、协议码、不可读 `.dat` 与候选路径只在 debug/full 输出中出现。

## 严格只读

普通读取不会修改微信数据库，但可能刷新本地 metadata/key、解码图片或缓存语音转写。需要连这些辅助写入也禁用时：

```bash
wechat-cli --strict-read-only timeline "聊天名" --limit 20
WECHAT_CLI_STRICT_READ_ONLY=1 wechat-cli agent --pretty
```

严格只读会禁用：

- metadata / key 自动刷新
- 图片解码与语音转写缓存
- `cache refresh/rebuild`
- `export`
- Companion 已移出本仓库。

## 图片与语音

图片、视频和文件默认返回可直接读取的本机 `path`。本地 `.dat` 图片会尽力解码到 `~/.wechat-cli/media-cache`；失败时返回 warning，不把不可读文件伪装成图片。

语音转写是可选能力：

```bash
wechat-cli asr setup --model large-v3
wechat-cli asr status --pretty
```

它会创建 `~/.wechat-cli/asr-venv`，安装 `faster-whisper` 与 `silk-python`。模型、语言、device 与 compute type 会持久化到本机 ASR 配置。首次模型下载可能占用数 GB；只安装依赖可加 `--skip-model-download`。

## 更新与清理

```bash
wechat-cli update
wechat-cli update --dry-run
```

更新器下载 latest release，校验 sha256，并保留当前自定义安装目录。

清理前先 dry-run：

```bash
./install.sh --clear-state --dry-run --json
./install.sh --uninstall --purge-state --dry-run --json
```

Windows：

```powershell
.\install.ps1 -ClearState -DryRun -Json
.\install.ps1 -Uninstall -PurgeState -DryRun -Json
```

危险目录会被拒绝；卸载只删除受管理的安装目录。`--purge-state` 会额外清除本机 key/config/cache/log 与托管凭据。

## 排障

| 现象 | 处理 |
| --- | --- |
| `readiness=degraded` | 查看 `status.data.status.warnings`；缓存滞后不等于聊天正文滞后 |
| 名字解析失败或有重名 | 先运行 `resolve-chat`，再把返回的 raw username 传给 `--chat/--talker` |
| 某个聊天缺 key | 在微信中打开对应聊天，随后由 agent 重跑 `wxkey bootstrap` / `doctor` |
| macOS 频繁弹隐私授权 | 给安装目录中的 `wechat-cli` 与 `wxkey` 加 Full Disk Access |
| 图片只有 warning | 在微信中打开原图后重试，并检查 image-key 诊断 |
| Windows 首次刷新失败 | 确认微信登录，且 `WECHAT_CLI_DB_ROOT` 直接包含 `db_storage` |
| `zsh: killed`，连 `--help` 都失败 | 重新运行 release bootstrap；旧二进制可能无法自更新 |

更完整的 Windows 说明见 [docs/WINDOWS_USER_GUIDE.md](docs/WINDOWS_USER_GUIDE.md)。安全问题请按 [SECURITY.md](SECURITY.md) 私下报告，不要在公开 issue 附上 key、数据库、聊天导出或日志。

## 开发

```bash
go test ./...
go vet ./...
go test -race ./...
```

发布包必须从与 `appVersion` 一致的干净 tag 构建；打包脚本会校验版本、架构、WCDB 导出与产物身份。

许可证与第三方组件见 [LICENSE](LICENSE) 与 [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)。


## Source and release governance

Canonical source: `r266-tech/wx-cli`. Release assets: `r266-tech/wechat-cli-releases`.
Go v2 module path: `github.com/r266-tech/wx-cli/v2` (semantic import versioning).
The CLI remains `wechat-cli`; existing installation, configuration, state and
Keychain service paths are retained. The old Go module import path is not supported.

The initial source tag does not constitute an accepted v2 release. A candidate
must pass the release gates in `docs/RELEASE_GOVERNANCE.md` before becoming stable.
Candidate builds are never installed by the default release bootstrap.
