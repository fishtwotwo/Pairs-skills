# Security

wechat-cli is a local-first tool for reading WeChat data on a Mac controlled by the
user running it. It does not require or use a remote service.

## Sensitive Local State

The following files are intentionally local and must not be committed or shared:

- `~/.config/wxcli/config.json`: contains account and DB references; legacy schema 2 may contain secrets. Schema 3 keeps runtime secrets in Keychain.
- `~/.wechat-cli/cache/`: contains metadata indexes; explicit plaintext archives are kept separately.
- macOS wxkey sudo credential in Keychain: contains the user's stored sudo password for unattended no-SIP key refresh.
- `dist/`, `wechat-cli`, `wxkey`, and local `libWCDB.dylib` build artifacts.

The repository `.gitignore` excludes the common local artifacts, but users should
still review `git status --short` before publishing changes.

## Permissions

wechat-cli reads local WeChat databases in readonly mode. First-run key extraction is
handled by the companion `wxkey` CLI and requests administrator privileges to
read the local WeChat process memory. The supported path is no-SIP only:
`wxkey bootstrap` stores the user's sudo password in macOS Keychain, prepares an
ad-hoc signed wechat-cli shadow copy of WeChat when the installed app is protected by
macOS app-management controls, and future key refreshes reuse the Keychain
credential through `sudo -S`.

Run these commands when diagnosing a new machine:

```bash
./install.sh --doctor --json
./wxkey doctor
./wechat-cli cache status
```

## Reporting Issues

Please avoid including message contents, DB keys, raw `config.json`, plaintext
cache files, or personal identifiers in public issues. Redact local paths and
account identifiers when possible.

## Public repository boundary

This project is limited to read-only access to WeChat data on the user's own
machine. It does not provide remote target access, bulk account collection,
message sending, UI automation, auto-reply, or cloud upload of keys, databases,
archives, or chat content. Do not submit real account data or key material in
issues, pull requests, logs, or test fixtures.
